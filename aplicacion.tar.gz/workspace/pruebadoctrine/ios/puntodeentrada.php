<?php
header('Content-Type: application/json');

require_once('../clases/AutoCarga.php');
require_once('../clases/vendor/autoload.php');

$json = json_decode(file_get_contents('php://input'));//convierte la cadena json en un objeto
$parametros = explode('/', $_GET['url']);
$metodo = $_SERVER['REQUEST_METHOD'];

$api = new Api($metodo, $json, $parametros);
$api->doTask();
echo $api->getResponse();