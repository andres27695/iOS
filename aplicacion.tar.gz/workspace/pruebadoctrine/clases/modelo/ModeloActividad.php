<?php

class ModeloActividad {
    
    private $gestor;
    
    function __construct(){
        $bs = new Bootstrap();
        $this->gestor = $bs->getEntityManager();
    }
    function getGestor(){
        return $this->gestor;
    }
    
    function insertActividad(Actividad $objeto){
        $this->gestor->persist($objeto);
        $this->gestor->flush();
        return $objeto->getId();
    }
    
    function deleteActividad($id){
        try{
            $actividad = $this->gestor->find('Actividad', $id);
            $this->gestor->remove($actividad);
            $this->gestor->flush();
            return 0;
        }catch( Exception $e){
            return 1;
        }
    
    }
    
    function updateActividad(Actividad $objeto){
        try{
            $this->gestor->merge($objeto);
            $this->gestor->flush();
            return 0;
        }catch(Exception $e){
            return 1;
        }
    
    }
    
    function getActividad($id){
        $actividad = $this->gestor->find('Actividad', $id);
        return $actividad;
    }
    
    function getActividades(){
        $actividades=$this->gestor->getRepository("Actividad")->findAll();
        return $actividades;
    }
}