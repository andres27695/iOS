<?php

class ModeloProfesor {
    
    private $gestor;
    
    function __construct(){
        $bs = new Bootstrap();
        $this->gestor = $bs->getEntityManager();
    }
    
    function insertProfesor(Profesor $objeto){
        $this->gestor->persist($objeto);
        $this->gestor->flush();
        return $objeto->getId();
    }
    
    function deleteProfesor($id){
        try{
            $profesor = $this->gestor->find('Profesor', $id);
            $this->gestor->remove($profesor);
            $this->gestor->flush();
            return 0;
        }catch( Exception $e){
            return 1;
        }
    
    }
    
    function updateProfesor(Profesor $objeto){
        try{
            $this->gestor->merge($objeto);
            $this->gestor->flush();
            return 0;
        }catch(Exception $e){
            return 1;
        }
    
    }
    
    function getProfesor($id){
        $profesor = $this->gestor->find('Profesor', $id);
        return $profesor;
    }
    
    function getProfesores(){
        $profesores=$this->gestor->getRepository("Profesor")->findAll();
        return $profesores;
    }
}