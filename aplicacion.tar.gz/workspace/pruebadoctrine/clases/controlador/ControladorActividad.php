<?php

class ControladorActividad extends Controlador{
    function post(){
        $actividad = new Actividad();
        $modelo = new ModeloActividad();
        $profesor = $modelo->getGestor()->getReference('Profesor', $this->getObject()->idProfesor);
        $actividad->setIdProfesor($profesor);
        $actividad->setNombre($this->getObject()->nombre);
        $actividad->setDescripcionCorta($this->getObject()->descripcionCorta);
        $actividad->setDescripcionLarga($this->getObject()->descripcionLarga);
        $actividad->setGrupo($this->getObject()->grupo);
        $actividad->setFecha(date_create($this->getObject()->fecha));
        $actividad->setLugar($this->getObject()->lugar);
        $actividad->setHoraInicio(date_create($this->getObject()->horaInicio));
        $actividad->setHoraFin(date_create($this->getObject()->horaFin));
        var_dump($actividad);
        $id=$modelo->insertActividad($actividad);
        var_dump($id);
        return array('id' => $id, 'idProfesor' => $actividad->getIdProfesor()->getId(),
        'descripcionCorta' => $actividad->getDescripcionCorta(),
        'descripcionLarga'=> $actividad->getDescripcionLarga(),
        'grupo'=>$actividad->getGrupo(),
        'fecha'=>$actividad->getFecha(),
        'lugar'=>$actividad->getLugar(),
        'horaInicio'=>$actividad->getHoraInicio(),
        'horaFin'=>$actividad->getHoraFin());
    }
    
    function get(){
            $modelo = new ModeloActividad();
            $actividades=$modelo->getActividades();
            
           foreach ($actividades as $actividad) {
                $resultado[] = array(
                    'id' => $actividad->getId(),
                    'nombre'=> $actividad->getNombre(),
                    'idProfesor' =>$actividad->getIdProfesor()->getId(),
                    'nombreProfesor' => $actividad->getIdProfesor()->getNombre(),
                    'departamento' => $actividad-> getIdProfesor()->getDepartamento(),
                    'descripcionCorta' => $actividad -> getDescripcionCorta(),
                    'descripcionLarga'=> $actividad-> getDescripcionLarga(),
                    'grupo'=> $actividad->getGrupo(),
                    'fecha'=> date_format($actividad->getFecha(), 'Y-M-d'),
                    'lugar'=>$actividad->getLugar(),
                    'horaInicio'=>$actividad-> getHoraInicio()->format('H:i'),
                    'horaFin'=>$actividad-> getHoraFin()->format('H:i'),
                );
            }
            return $resultado;
    }
    
    function delete(){
        $modelo=new ModeloActividad();
        $success=$modelo->deleteActividad($this->getObject()->id);
        if($success==0){
            return "Borrado";
        }else{
            return "No se ha podido borrar al profesor";
        }
    }
    
    function put(){
        $modelo = new ModeloActividad();
        $actividad = $modelo->getGestor()->find('Actividad', $this->getObject()->id);
        $actividad->setId($this->getObject()->id);
        $profesor = $modelo->getGestor()->getReference('Profesor', $this->getObject()->idProfesor);
        $actividad->setIdProfesor($profesor);
        $actividad->setDescripcionCorta($this->getObject()->descripcionCorta);
        $actividad->setDescripcionLarga($this->getObject()->descripcionLarga);
        $actividad->setGrupo($this->getObject()->grupo);
        $actividad->setFecha(date_create($this->getObject()->fecha));
        $actividad->setLugar($this->getObject()->lugar);
        $actividad->setHoraInicio(date_create($this->getObject()->horaInicio));
        $actividad->setHoraFin(date_create($this->getObject()->horaFin));
        $success=$modelo->updateActividad($actividad);
        if($success==0){
            return "Se ha actualizado el profesor";
        }else{
            return "No se ha podido actualizar al profesor";
        }
    }
    
    
}