<?php

class Controlador{
    
    private $objeto, $rest, $get;
    
    function __construct($objeto, $rest, $get){
        $this->objeto = $objeto;
        $this->rest = $rest;
        $this->get = $get;
    }
    
    //getter

    function getUrlParameters(){
        return $this->get;
    }

    function getObject(){
        return $this->objeto;
    }

    function getRestParameters(){
        return $this->rest;
    }

    //métodos REST

    function delete(){
        return '{}';
    }

    function get(){
        return '{}';
    }
    
    function post(){
        return '{}';
    }
    
    function put(){
        return '{}';
    }
    
}