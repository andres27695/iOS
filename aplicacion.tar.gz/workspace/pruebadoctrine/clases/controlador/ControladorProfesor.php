<?php

class ControladorProfesor extends Controlador{
    
    function post(){
        $p = new Profesor();
        $p->setNombre($this->getObject()->nombre);
        $p->setDepartamento($this->getObject()->departamento);
        $modelo = new ModeloProfesor();
        $id=$modelo->insertProfesor($p);
        return array('id' => $id, 'nombre' => $p->getNombre(), 'departamento' => $p->getDepartamento() );
    }
    
    function get(){
            $modelo = new ModeloProfesor();
            $profesores=$modelo->getProfesores();
            foreach ($profesores as $profesor) {
                $resultado[] = array(
                    'id' => $profesor->getId(),
                    'nombre' =>$profesor->getNombre(),
                    'departamento' => $profesor -> getDepartamento()
                );
            }
            return $resultado;
    }
    
    function delete(){
        $modelo=new ModeloProfesor();
        $success=$modelo->deleteProfesor($this->getObject()->id);
        if($success==0){
            return "Borrado";
        }else{
            return "No se ha podido borrar al profesor";
        }
    }
    
    function put(){
        $p = new Profesor();
        $p->setId($this->getObject()->id);
        $p->setNombre($this->getObject()->nombre);
        $p->setDepartamento($this->getObject()->departamento);
        $modelo=new ModeloProfesor();
        $success=$modelo->updateProfesor($p);
        if($success==0){
            return "Se ha actualizado el profesor";
        }else{
            return "No se ha podido actualizar al profesor";
        }
    }
}