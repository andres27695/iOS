<?php
use Doctrine\Common\Collections\ArrayCollection;

/**
 * @Entity @Table(name="actividad")
 * uniqueConstraints={@UniqueConstraint(name="tp_unique",columns={"idProfesor","actividad"})})
 **/
class Actividad {
    
    /**
     * @var int
     * @Id
     * @Column(type="integer") @GeneratedValue
     */
    protected $id;
    
    /**
     * @var string
     * @Column(type="string",length=100, unique=true)
     */
    protected $nombre;
    
    /**
     * @var int
     * @ManyToOne(targetEntity="Profesor", inversedBy="id")
     * @JoinColumn(name="idProfesor", referencedColumnName="id")
     */
    protected $idprofesor;
    
    /**
     * @var string
     * @Column(type="string", length=100, unique=false, nullable=true)
     */
    protected $descripcionCorta;
    
    /**
     * @var string
     * @Column(type="string", length=300, unique=false, nullable=true)
     */
    protected $descripcionLarga;
    
     /**
     * @var string
     * @Column(type="string", length=100, unique=false, nullable=true)
     */
    protected $grupo;
    
     /**
     * @var date
     * @Column(type="date")
     */
    protected $fecha;
    
     /**
     * @var string
     * @Column(type="string", length=100, unique=false, nullable=true)
     */
    protected $lugar;
    
     /**
     * @var time
     * @Column(type="time")
     */
    protected $horaInicio;
    
    /**
     * @var time
     * @Column(type="time")
     */
    protected $horaFin;
    

    public function getId() {
        return $this->id;
    }
    public function getNombre(){
        return $this->nombre;
    }

    public function getIdProfesor() {
        return $this->idprofesor;
    }

    public function getDescripcionCorta() {
        return $this->descripcionCorta;
    }

    public function getDescripcionLarga() {
        return $this->descripcionLarga;
    }

    public function getGrupo() {
        return $this->grupo;
    }

    public function getFecha() {
        return $this->fecha;
    }
        
    public function getLugar() {
        return $this->lugar;
    }
    
    public function getHoraInicio() {
        return $this->horaInicio;
    }
    
    public function getHoraFin() {
        return $this->horaFin;
    }
    
    
    public function setId($id) {
        $this->id = $id;
        return $this;
    }
    
    public function setNombre($nombre){
        $this->nombre = $nombre;
        return $this;
    }
    public function setIdProfesor($id) {
        $this->idprofesor = $id;
        return $this;
    }
    
    public function setDescripcionCorta($descripcion) {
        $this->descripcionCorta = $descripcion;
        return $this;
    }

    public function setDescripcionLarga($descripcion) {
        $this->descripcionLarga = $descripcion;
        return $this;
    }
    
    public function setGrupo($grupo) {
        $this->grupo = $grupo;
        return $this;
    }
    
    public function setFecha($fecha) {
        $this->fecha = $fecha;
        return $this;
    }
    
    public function setLugar($lugar) {
        $this->lugar = $lugar;
        return $this;
    }
    
    public function setHoraInicio($horaInicio) {
        $this->horaInicio = $horaInicio;
        return $this;
    }
    
    public function setHoraFin($horaFin) {
        $this->horaFin = $horaFin;
        return $this;
    }
    
    function __toString(){
        return $this->getId() . ' ' . $this->getIdProfesor() . ' ' . $this->getDescripcionCorta(). ' ' . $this->getDescripcionLarga().
        ' ' . $this->getGrupo(). ' ' . $this->getFecha(). ' ' . $this->getLugar(). ' ' . $this->getHoraInicio(). ' ' . $this->getHoraFin();
    }
}