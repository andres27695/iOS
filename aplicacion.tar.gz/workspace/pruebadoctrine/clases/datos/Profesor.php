<?php
use Doctrine\Common\Collections\ArrayCollection;

/**
 * @Entity @Table(name="profesor")
 **/
class Profesor {
    
    /**
     * @var int
     * @Id
     * @Column(type="integer") @GeneratedValue
     * @OneToMany(targetEntity="Actividad", mappedBy="profesor")
     */
    protected $id;
    
    /**
     * @var string
     * @Column(type="string", length=100, unique=false, nullable=true)
     */
    protected $nombre;
    
    /**
     * @var string
     * @Column(type="string", length=100, unique=false, nullable=true)
     */
    protected $departamento;
    
    public function getId() {
        return $this->id;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function getDepartamento() {
        return $this->departamento;
    }

    public function setId($id) {
        $this->id = $id;
        return $this;
    }

    public function setNombre($nombre) {
        $this->nombre = $nombre;
        return $this;
    }
    
    public function setDepartamento($departamento) {
        $this->departamento = $departamento;
        return $this;
    }

    function __toString(){
        return $this->getId() . ' ' . $this->getNombre() . ' ' . $this->getDepartamento();
    }
}